# ♠ Poker entre potes

Texas Hold'em no-limit multijoueur (2 à 9 joueurs) qui tourne entièrement dans le navigateur.
Il n'y a pas de serveur, donc ça s'héberge gratuitement sur **GitHub Pages**.

## Mettre en ligne sur GitHub Pages

1. Crée un dépôt sur GitHub (par ex. `poker-potes`), public.
2. Mets-y les fichiers `index.html`, `style.css`, `poker.js` et `app.js` à la racine.
   Tu peux passer par **Add file → Upload files** sur la page du dépôt, ou en ligne de commande :
   ```bash
   git init && git add . && git commit -m "Poker entre potes"
   git branch -M main
   git remote add origin https://github.com/TON-PSEUDO/poker-potes.git
   git push -u origin main
   ```
3. Dans le dépôt : **Settings → Pages → Build and deployment → Source : Deploy from a branch**,
   choisis la branche `main` et le dossier `/ (root)`, puis **Save**.
4. Une minute plus tard, le jeu est accessible sur `https://TON-PSEUDO.github.io/poker-potes/`.

## Jouer

1. Une personne ouvre le site, entre son pseudo et clique sur **Créer une table**. C'est elle l'**hôte** 👑.
2. Elle clique sur **Copier le lien d'invitation** et l'envoie au groupe. Les autres peuvent aussi taper le code à 6 caractères.
3. Quand tout le monde est là, l'hôte clique sur **Lancer la partie**.

**Important : l'hôte doit garder sa page ouverte.** C'est son navigateur qui fait tourner la partie.
S'il ferme l'onglet, la table disparaît. Un joueur qui perd la connexion peut recharger la page et retrouver sa place (mêmes jetons).

### Ce qui est géré
- Blindes, tours d'enchères complets, relance minimale, tapis, pots annexes (side pots), partage des pots
- Évaluation automatique des mains à l'abattage, avec les cartes gagnantes mises en valeur
- Recave quand on n'a plus de jetons, et enchaînement automatique des mains (désactivable)
- Réglages de l'hôte : tapis de départ, petite et grosse blinde
- Chat, journal de la partie, son et vibration quand c'est ton tour, affichage mobile
- L'hôte peut coucher un joueur qui ne répond plus

## Comment ça marche

- Les connexions passent en pair-à-pair (WebRTC) grâce à [PeerJS](https://peerjs.com/). Leur serveur public gratuit sert uniquement à mettre les navigateurs en relation.
- Le navigateur de l'hôte mélange le paquet (avec `crypto.getRandomValues`) et calcule tout le jeu.
  Chaque joueur ne reçoit **que ses propres cartes** : impossible de voir celles des autres en fouillant la page.
  Seul l'hôte pourrait techniquement tricher en bidouillant son navigateur. Entre potes, ça va 😉

## Limites connues
- Sur certains réseaux très fermés (réseaux d'entreprise, certains partages de connexion 4G), la connexion WebRTC peut échouer faute de serveur relais (TURN). Changer de réseau règle généralement le problème.
- Pas de minuteur automatique : si quelqu'un s'endort, l'hôte peut le coucher depuis son panneau.

## Fichiers
| Fichier | Rôle |
|---|---|
| `index.html` | Structure de la page |
| `style.css` | Apparence (table, cartes, mobile) |
| `poker.js` | Moteur de jeu : distribution, enchères, pots, évaluation des mains |
| `app.js` | Interface et réseau |
