/* Interface + réseau pair-à-pair (PeerJS / WebRTC).
   Le navigateur qui crée la table est l'"hôte" : il fait tourner le moteur et
   n'envoie à chaque joueur que ses propres cartes. */
(function () {
  'use strict';
  const PREFIX = 'pokerpotes-v1-';
  const $ = s => document.querySelector(s);
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const { RANKS, SUITS, rankOf, suitOf } = window.Poker;

  // Jeton secret de ce navigateur (sert à retrouver sa place après une coupure)
  function store(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } }
  let token = store('pp-token');
  if (!token) { token = Array.from(crypto.getRandomValues(new Uint8Array(16)), b => b.toString(16).padStart(2, '0')).join(''); store('pp-token', token); }

  let mode = null;          // 'host' | 'client'
  let peer = null, hostConn = null, game = null, code = '';
  const conns = new Map();  // peerId -> { conn, pid }
  const tokenToPid = new Map();
  let myPid = null;
  let view = null;
  let autoTimer = null, autoNext = true;
  let actionKey = '';
  let gotState = false;

  // ---------- Accueil ----------
  const params = new URLSearchParams(location.search);
  const roomParam = (params.get('room') || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
  $('#name').value = store('pp-name') || '';
  if (roomParam) {
    $('#join-box').classList.remove('hidden');
    $('#create-box').classList.add('hidden');
    $('#join-code').textContent = roomParam;
  }
  $('#btn-other').onclick = () => {
    history.replaceState(null, '', location.pathname);
    $('#join-box').classList.add('hidden'); $('#create-box').classList.remove('hidden');
  };
  const getName = () => {
    const n = $('#name').value.trim();
    if (!n) { homeMsg('Choisis un pseudo 🙂'); $('#name').focus(); return null; }
    store('pp-name', n); return n;
  };
  $('#btn-create').onclick = () => { const n = getName(); if (n) hostCreate(n); };
  $('#btn-join').onclick = () => { const n = getName(); if (n) clientJoin(roomParam, n); };
  $('#btn-join-code').onclick = () => {
    const c = $('#code').value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (c.length !== 6) return homeMsg('Le code fait 6 caractères');
    const n = getName(); if (n) clientJoin(c, n);
  };
  $('#code').addEventListener('keydown', e => { if (e.key === 'Enter') $('#btn-join-code').click(); });
  $('#name').addEventListener('keydown', e => { if (e.key === 'Enter') (roomParam ? $('#btn-join') : $('#btn-create')).click(); });

  function homeMsg(t) { $('#home-msg').textContent = t; }
  function setBusy(b) { document.querySelectorAll('#home button').forEach(x => { x.disabled = b; }); }

  function genCode() {
    const A = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    return Array.from(crypto.getRandomValues(new Uint8Array(6)), b => A[b % A.length]).join('');
  }

  function inviteLink() { return `${location.origin}${location.pathname}?room=${code}`; }

  // ---------- Hôte ----------
  function hostCreate(name, tries = 0) {
    setBusy(true); homeMsg('Création de la table…');
    code = genCode();
    peer = new Peer(PREFIX + code);
    peer.on('open', () => {
      mode = 'host';
      game = new Poker.Game({ onChange: broadcast });
      myPid = pidFor(token);
      game.join(myPid, name);
      enterGame();
      broadcast();
      toast('Table créée ! Envoie le lien à tes potes.');
    });
    peer.on('error', e => {
      if (e.type === 'unavailable-id' && tries < 3) { peer.destroy(); return hostCreate(name, tries + 1); }
      if (!mode) { setBusy(false); homeMsg('Impossible de créer la table : ' + (e.type || e.message)); }
      else toast('Erreur réseau : ' + (e.type || e.message));
    });
    peer.on('disconnected', () => { if (!peer.destroyed) setTimeout(() => peer.reconnect(), 1000); });
    peer.on('connection', conn => {
      conn.on('data', m => onHostMsg(conn, m));
      conn.on('close', () => onConnClose(conn));
      conn.on('error', () => onConnClose(conn));
    });
  }

  function pidFor(tok) {
    if (!tokenToPid.has(tok)) tokenToPid.set(tok, 'p' + Math.random().toString(36).slice(2, 10));
    return tokenToPid.get(tok);
  }

  function onConnClose(conn) {
    const c = conns.get(conn.peer);
    if (!c || c.conn !== conn) return;
    conns.delete(conn.peer);
    const stillHere = [...conns.values()].some(x => x.pid === c.pid);
    if (!stillHere) game.disconnect(c.pid);
    broadcast();
  }

  function onHostMsg(conn, m) {
    if (!m || typeof m !== 'object') return;
    try {
      if (m.t === 'join') {
        if (typeof m.token !== 'string' || m.token.length < 8 || m.token === token) throw new Error('Jeton invalide');
        const pid = pidFor(m.token);
        // une seule connexion par joueur
        for (const [k, c] of conns) if (c.pid === pid && c.conn !== conn) { conns.delete(k); try { c.conn.close(); } catch (e) {} }
        game.join(pid, String(m.name || '').trim().slice(0, 16) || 'Joueur');
        conns.set(conn.peer, { conn, pid });
        broadcast();
        return;
      }
      const c = conns.get(conn.peer);
      if (!c || c.conn !== conn) return;
      handle(c.pid, m);
    } catch (e) {
      try { conn.send({ t: 'error', msg: e.message }); } catch (_) {}
    }
  }

  // Actions d'un joueur (hôte compris), exécutées chez l'hôte
  function handle(pid, m) {
    const p = game.player(pid);
    if (!p) throw new Error("Tu n'es pas à la table");
    if (m.t === 'act') game.act(pid, String(m.action), m.amount);
    else if (m.t === 'rebuy') { game.rebuy(pid); broadcast(); }
    else if (m.t === 'chat') {
      const text = String(m.text || '').trim().slice(0, 140);
      if (text) { game.addLog(`${p.name}|${text}`, 'chat'); broadcast(); }
    }
  }

  function broadcast() {
    if (mode !== 'host' || !game) return;
    const extra = { code, hostPid: myPid };
    for (const { conn, pid } of conns.values()) {
      if (conn.open) { try { conn.send({ t: 'state', v: game.viewFor(pid, extra) }); } catch (e) {} }
    }
    render(game.viewFor(myPid, Object.assign({ isHost: true }, extra)));
    // main suivante automatique
    const ready = game.players.filter(p => p.chips > 0 && p.connected).length >= 2;
    if ((game.stage === 'done' || (game.stage === 'waiting' && game.handNo > 0 && ready)) && autoNext && !autoTimer) {
      autoTimer = setTimeout(() => {
        autoTimer = null;
        if ((game.stage === 'done' || game.stage === 'waiting') && autoNext) game.startHand();
      }, game.stage === 'done' ? 6000 : 2500);
    }
  }

  // ---------- Client ----------
  function clientJoin(c, name) {
    code = c; setBusy(true); homeMsg('Connexion à la table ' + c + '…');
    gotState = false;
    peer = new Peer();
    peer.on('open', () => {
      hostConn = peer.connect(PREFIX + c, { reliable: true });
      hostConn.on('open', () => hostConn.send({ t: 'join', token, name }));
      hostConn.on('data', m => {
        if (!m) return;
        if (m.t === 'state') {
          if (!gotState) { gotState = true; mode = 'client'; enterGame(); history.replaceState(null, '', '?room=' + c); }
          render(m.v);
        } else if (m.t === 'error') toast(m.msg);
      });
      hostConn.on('close', () => { if (gotState) showOverlay("La connexion avec l'hôte a été perdue. Si l'hôte est toujours là, recharge la page : tu retrouveras ta place.", true); });
      setTimeout(() => {
        if (!gotState) { setBusy(false); homeMsg("Pas de réponse de la table. Vérifie le code, ou que l'hôte a toujours la page ouverte."); try { peer.destroy(); } catch (e) {} }
      }, 15000);
    });
    peer.on('error', e => {
      if (e.type === 'peer-unavailable') { setBusy(false); homeMsg('Table introuvable : vérifie le code (ou l\'hôte a fermé sa page).'); try { peer.destroy(); } catch (_) {} }
      else if (!gotState) { setBusy(false); homeMsg('Erreur de connexion : ' + (e.type || e.message)); }
      else toast('Erreur réseau : ' + (e.type || e.message));
    });
  }

  function send(m) {
    if (mode === 'host') {
      try { handle(myPid, m); } catch (e) { toast(e.message); }
    } else if (hostConn && hostConn.open) hostConn.send(m);
    else toast("Pas connecté à l'hôte");
  }

  // ---------- Écran de jeu ----------
  function enterGame() {
    $('#home').classList.add('hidden');
    $('#game').classList.remove('hidden');
    $('#room-code').textContent = code;
  }
  $('#btn-invite').onclick = async () => {
    const link = inviteLink();
    try { await navigator.clipboard.writeText(link); toast('Lien copié : ' + link); }
    catch (e) { prompt("Copie ce lien et envoie-le à tes potes :", link); }
  };
  $('#btn-log').onclick = () => $('#side').classList.toggle('open');
  $('#chat').onsubmit = e => {
    e.preventDefault();
    const t = $('#chat-input').value.trim();
    if (t) send({ t: 'chat', text: t });
    $('#chat-input').value = '';
  };
  $('#overlay-btn').onclick = () => { location.href = location.pathname + (mode === 'client' ? '?room=' + code : ''); };
  window.addEventListener('beforeunload', e => {
    if (mode === 'host' && conns.size) { e.preventDefault(); e.returnValue = ''; }
  });

  function showOverlay(msg, reload) {
    $('#overlay-msg').textContent = msg;
    $('#overlay-btn').textContent = reload ? 'Se reconnecter' : "Retour à l'accueil";
    $('#overlay').classList.remove('hidden');
  }

  let toastT;
  function toast(t) {
    const el = $('#toast'); el.textContent = t; el.classList.add('show');
    clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('show'), 2800);
  }

  // n'animer que les cartes qui viennent d'apparaître (sinon tout clignote à chaque mise à jour)
  let seen = new Set(), seenHand = null;
  function fresh(key) {
    if (seen.has(key)) return '';
    seen.add(key); return 'new';
  }
  function cardHTML(c, extraCls = '', key = '') {
    if (key) extraCls += ' ' + fresh(key + ':' + c);
    if (c === null || c === undefined) return `<div class="card back ${extraCls}"></div>`;
    const r = RANKS[rankOf(c) - 2], s = suitOf(c);
    return `<div class="card ${s === 1 || s === 2 ? 'red' : ''} ${extraCls}"><span class="r">${r === 'T' ? '10' : r}</span><span class="s">${SUITS[s]}</span></div>`;
  }

  const fmt = n => Number(n).toLocaleString('fr-FR');

  function beep() {
    try {
      const ac = beep.ac || (beep.ac = new (window.AudioContext || window.webkitAudioContext)());
      const o = ac.createOscillator(), g = ac.createGain();
      o.frequency.value = 880; o.type = 'sine';
      g.gain.setValueAtTime(.0001, ac.currentTime);
      g.gain.exponentialRampToValueAtTime(.15, ac.currentTime + .02);
      g.gain.exponentialRampToValueAtTime(.0001, ac.currentTime + .25);
      o.connect(g).connect(ac.destination); o.start(); o.stop(ac.currentTime + .3);
      if (navigator.vibrate) navigator.vibrate(80);
    } catch (e) {}
  }

  function render(v) {
    const prevTurn = view && view.turn, prevHand = view && view.handNo;
    view = v;
    if (seenHand !== v.handNo) { seen = new Set(); seenHand = v.handNo; }
    const me = v.players.find(p => p.id === v.me);
    const narrow = $('#table').clientWidth < 520;
    const portrait = $('#table').clientHeight > $('#table').clientWidth;

    // Sièges : moi en bas, les autres dans l'ordre autour de la table
    const n = v.players.length;
    const myIdx = Math.max(0, v.players.findIndex(p => p.id === v.me));
    const winners = new Set(((v.result && v.result.winners) || []).map(w => w.id));
    const winCards = new Set(((v.result && v.result.winners) || []).flatMap(w => w.cards || []));
    let seats = '', bets = '';
    v.players.forEach((p, i) => {
      const k = (i - myIdx + n) % n;
      const ang = Math.PI / 2 + (k * 2 * Math.PI) / Math.max(n, 2);
      const rx = portrait ? 44 : 52, ry = portrait ? 50 : 56;
      const x = 50 + rx * Math.cos(ang), y = 50 + ry * Math.sin(ang);
      const bx = 50 + (rx - 22) * Math.cos(ang), by = 50 + (ry - (portrait ? 18 : 26)) * Math.sin(ang);
      const cls = ['seat', p.id === v.me ? 'me' : '', p.id === v.turn ? 'turn' : '',
        p.inHand && p.folded ? 'folded' : '', !p.inHand ? 'out' : '', winners.has(p.id) && v.stage === 'done' ? 'winner' : ''].join(' ');
      const cards = p.cards.map((c, j) => cardHTML(c, winCards.has(c) && v.stage === 'done' ? 'win' : '', p.id + j)).join('');
      const handName = v.result && v.result.hands && v.result.hands[p.id] ? v.result.hands[p.id] : '';
      const status = !p.connected ? '<span class="off">déconnecté</span>'
        : (!p.inHand && v.stage !== 'waiting' ? (p.chips > 0 ? '<span class="off" style="color:var(--muted)">prochaine main</span>' : '<span class="off">éliminé</span>') : '');
      seats += `<div class="${cls}" style="left:${x}%;top:${y}%">
        <div class="cards">${cards}</div>
        <div class="plate">
          ${v.dealer === p.id ? '<div class="dealer">D</div>' : ''}
          ${p.lastAction ? `<div class="act">${esc(p.lastAction)}</div>` : ''}
          <div class="nm">${esc(p.name)}${p.id === v.me ? ' (toi)' : ''}${p.id === v.hostPid ? ' 👑' : ''}</div>
          <div class="ch">${fmt(p.chips)}</div>${status}
        </div>
        <div class="hand">${esc(handName)}</div>
      </div>`;
      if (p.bet > 0) bets += `<div class="bet" style="left:${bx}%;top:${by}%">${fmt(p.bet)}</div>`;
    });
    $('#seats').innerHTML = seats + bets;

    // Centre
    const slots = [0, 1, 2, 3, 4].map(i => v.board[i] !== undefined ? cardHTML(v.board[i], winCards.has(v.board[i]) && v.stage === 'done' ? 'win' : '', 'b' + i) : '<div class="card slot"></div>').join('');
    $('#board').innerHTML = v.stage === 'waiting' ? '' : slots;
    $('#pot').textContent = v.potTotal > 0 ? `Pot : ${fmt(v.potTotal)}` : '';
    let banner = '';
    if (v.stage === 'waiting') {
      banner = `<div class="waiting">${n < 2 ? 'En attente de joueurs…<br><small>Clique sur « Copier le lien d\'invitation » et envoie-le à tes potes.</small>'
        : (v.isHost ? 'Tout le monde est là ? Lance la partie !' : "En attente du lancement par l'hôte…")}</div>`;
    } else if (v.stage === 'done' && v.result) {
      banner = v.result.winners.map(w => `${esc(w.name)} gagne ${fmt(w.amount)}${w.hand ? ' — ' + esc(w.hand) : ''}`).join('<br>');
    }
    $('#banner').innerHTML = banner;

    renderActions(v, me);
    renderHostPanel(v);
    renderLog(v);

    if (v.turn === v.me && prevTurn !== v.me) { beep(); flashTitle(); }
    if (prevHand !== v.handNo) actionKey = '';
  }

  let titleT;
  function flashTitle() {
    if (!document.hidden) return;
    let on = false; clearInterval(titleT);
    titleT = setInterval(() => { document.title = (on = !on) ? '🔔 À toi de jouer !' : 'Poker entre potes'; }, 900);
    const stop = () => { clearInterval(titleT); document.title = 'Poker entre potes'; document.removeEventListener('visibilitychange', stop); };
    document.addEventListener('visibilitychange', stop);
  }

  function renderActions(v, me) {
    const box = $('#actions');
    const L = v.legal;
    const key = JSON.stringify([v.players.length, v.handNo, v.stage, v.turn, v.currentBet, L && L.myBet, me && me.chips, v.isHost && v.stage]);
    if (key === actionKey) return; // évite de réinitialiser le curseur pendant qu'on le manipule
    actionKey = key;

    if (!me) { box.innerHTML = '<span class="status">Spectateur</span>'; return; }
    const myHand = v.myBest ? `<span class="my-hand">${esc(v.myBest)}</span>` : '';

    if (L) {
      const pot = v.potTotal;
      const callLabel = L.canCheck ? 'Checker' : (L.toCall >= me.chips ? `Tapis ${fmt(L.toCall)}` : `Suivre ${fmt(L.toCall)}`);
      let raise = '';
      if (L.canRaise) {
        const verb = v.currentBet === 0 ? 'Miser' : 'Relancer à';
        const potTo = L.myBet + L.toCall + (pot + L.toCall);
        const halfTo = L.myBet + L.toCall + Math.floor((pot + L.toCall) / 2);
        const clamp = x => Math.max(L.minTo, Math.min(L.maxTo, Math.round(x)));
        raise = `<div class="raise-box">
          <div class="quick">
            <button class="btn" data-to="${clamp(L.minTo)}">Min</button>
            <button class="btn" data-to="${clamp(halfTo)}">½ pot</button>
            <button class="btn" data-to="${clamp(potTo)}">Pot</button>
          </div>
          <input type="range" id="r-range" min="${L.minTo}" max="${L.maxTo}" step="1" value="${L.minTo}">
          <input type="number" id="r-num" min="${L.minTo}" max="${L.maxTo}" value="${L.minTo}">
          <button class="btn primary" id="a-raise">${verb} <span id="r-lbl">${fmt(L.minTo)}</span></button>
        </div>`;
      }
      box.innerHTML = `${myHand}
        <button class="btn danger" id="a-fold">Se coucher</button>
        <button class="btn" id="a-call">${callLabel}</button>
        ${raise}
        <button class="btn" id="a-allin" ${me.chips > 0 ? '' : 'disabled'}>Tapis</button>`;
      $('#a-fold').onclick = () => {
        if (L.canCheck && !confirmFold()) return;
        send({ t: 'act', action: 'fold' });
      };
      $('#a-call').onclick = () => send({ t: 'act', action: L.canCheck ? 'check' : 'call' });
      $('#a-allin').onclick = () => send({ t: 'act', action: 'allin' });
      if (L.canRaise) {
        const rng = $('#r-range'), num = $('#r-num'), lbl = $('#r-lbl');
        const set = val => {
          const x = Math.max(L.minTo, Math.min(L.maxTo, Math.round(Number(val) || L.minTo)));
          rng.value = x; num.value = x; lbl.textContent = fmt(x) + (x === L.maxTo ? ' (tapis)' : '');
        };
        rng.oninput = () => set(rng.value);
        num.onchange = () => set(num.value);
        box.querySelectorAll('[data-to]').forEach(b => { b.onclick = () => set(b.dataset.to); });
        $('#a-raise').onclick = () => send({ t: 'act', action: 'raise', amount: Number(num.value) });
        num.onkeydown = e => { if (e.key === 'Enter') $('#a-raise').click(); };
      }
      return;
    }

    if (me.chips === 0 && (!me.inHand || v.stage === 'done' || v.stage === 'waiting')) {
      box.innerHTML = `<span class="status">Plus de jetons…</span><button class="btn primary" id="a-rebuy">Se recaver (${fmt(v.settings.stack)})</button>`;
      $('#a-rebuy').onclick = () => send({ t: 'rebuy' });
      return;
    }

    let st = '';
    const turnP = v.players.find(p => p.id === v.turn);
    if (v.stage === 'waiting') st = v.isHost ? '' : "En attente du lancement par l'hôte…";
    else if (v.stage === 'done') st = 'Main suivante dans quelques secondes…';
    else if (turnP) st = `Au tour de <b>${esc(turnP.name)}</b>`;
    else st = 'Les cartes sont retournées…';
    if (v.isHost && v.stage === 'waiting') {
      box.innerHTML = `<button class="btn primary" id="a-start" ${v.players.filter(p => p.chips > 0).length < 2 ? 'disabled' : ''}>Lancer la partie</button>`;
      $('#a-start').onclick = () => { game.startHand(); };
      return;
    }
    box.innerHTML = `${myHand}<span class="status">${st}</span>`;
  }

  function confirmFold() { return confirm('Tu peux checker gratuitement. Te coucher quand même ?'); }

  function renderHostPanel(v) {
    const panel = $('#host-panel');
    if (!v.isHost) { panel.classList.add('hidden'); return; }
    panel.classList.remove('hidden');
    const s = v.settings;
    const sig = JSON.stringify([s, v.stage === 'waiting', v.stage === 'done', autoNext, v.turn]);
    if (panel.dataset.sig === sig) return;
    panel.dataset.sig = sig;
    const turnP = v.players.find(p => p.id === v.turn);
    panel.innerHTML = `<h3>Réglages de l'hôte</h3>
      <div class="row">
        <label>Tapis de départ<input type="number" id="s-stack" min="100" step="100" value="${s.stack}"></label>
        <label>Petite blinde<input type="number" id="s-sb" min="1" value="${s.sb}"></label>
        <label>Grosse blinde<input type="number" id="s-bb" min="2" value="${s.bb}"></label>
      </div>
      <label class="check"><input type="checkbox" id="s-auto" ${autoNext ? 'checked' : ''}> Enchaîner les mains automatiquement</label>
      <div class="row">
        ${v.stage === 'done' && !autoNext ? '<button class="btn small primary" id="s-next">Main suivante</button>' : ''}
        ${turnP && turnP.id !== v.me ? `<button class="btn small" id="s-kick" title="Si un joueur ne répond plus">Coucher ${esc(turnP.name)}</button>` : ''}
      </div>
      <small style="color:var(--muted)">Les blindes changent à la main suivante. Le tapis de départ vaut pour les nouveaux joueurs et les recaves.</small>`;
    const upd = () => {
      const st = Math.max(1, parseInt($('#s-stack').value) || s.stack);
      const sb = Math.max(1, parseInt($('#s-sb').value) || s.sb);
      const bb = Math.max(sb, parseInt($('#s-bb').value) || s.bb);
      Object.assign(game.settings, { stack: st, sb, bb });
      if (game.stage === 'waiting') game.players.forEach(p => { if (p.total === 0 && game.handNo === 0) p.chips = st; });
      broadcast();
    };
    ['#s-stack', '#s-sb', '#s-bb'].forEach(id => { $(id).onchange = upd; });
    $('#s-auto').onchange = e => {
      autoNext = e.target.checked;
      if (!autoNext && autoTimer) { clearTimeout(autoTimer); autoTimer = null; }
      broadcast();
    };
    const nx = $('#s-next'); if (nx) nx.onclick = () => game.startHand();
    const kk = $('#s-kick'); if (kk) kk.onclick = () => { try { game.act(turnP.id, 'fold'); } catch (e) { toast(e.message); } };
  }

  let lastLogSig = '';
  function renderLog(v) {
    const sig = v.log.length + ':' + (v.log.length ? v.log[v.log.length - 1].t + v.log[v.log.length - 1].text : '');
    if (sig === lastLogSig) return;
    lastLogSig = sig;
    const el = $('#log');
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
    el.innerHTML = v.log.map(l => {
      if (l.kind === 'chat') {
        const i = l.text.indexOf('|');
        return `<div class="chat"><b>${esc(l.text.slice(0, i))}</b> : ${esc(l.text.slice(i + 1))}</div>`;
      }
      return `<div class="${esc(l.kind)}">${esc(l.text)}</div>`;
    }).join('');
    if (atBottom) el.scrollTop = el.scrollHeight;
  }

  window.addEventListener('resize', () => { if (view) { actionKey = ''; render(view); } });
})();
