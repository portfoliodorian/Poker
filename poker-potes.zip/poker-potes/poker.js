/* Moteur Texas Hold'em No-Limit — tourne chez l'hôte de la table. */
(function (root) {
  'use strict';

  const RANKS = '23456789TJQKA';
  const SUITS = ['♠', '♥', '♦', '♣'];
  const HAND_NAMES = ['Carte haute', 'Paire', 'Double paire', 'Brelan', 'Quinte',
    'Couleur', 'Full', 'Carré', 'Quinte flush'];

  const rankOf = c => (c % 13) + 2;
  const suitOf = c => Math.floor(c / 13);

  function randInt(n) {
    if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
      const buf = new Uint32Array(1);
      const lim = Math.floor(0x100000000 / n) * n;
      do { crypto.getRandomValues(buf); } while (buf[0] >= lim);
      return buf[0] % n;
    }
    return Math.floor(Math.random() * n);
  }

  function shuffledDeck() {
    const d = Array.from({ length: 52 }, (_, i) => i);
    for (let i = d.length - 1; i > 0; i--) {
      const j = randInt(i + 1);
      [d[i], d[j]] = [d[j], d[i]];
    }
    return d;
  }

  // ---------- Évaluation ----------
  function eval5(cards) {
    const rs = cards.map(rankOf).sort((a, b) => b - a);
    const flush = cards.every(c => suitOf(c) === suitOf(cards[0]));
    const uniq = [...new Set(rs)];
    let straightTop = 0;
    if (uniq.length === 5) {
      if (rs[0] - rs[4] === 4) straightTop = rs[0];
      else if (rs[0] === 14 && rs[1] === 5) straightTop = 5; // roue A-5
    }
    const counts = {};
    rs.forEach(r => { counts[r] = (counts[r] || 0) + 1; });
    const groups = Object.keys(counts).map(Number)
      .sort((a, b) => counts[b] - counts[a] || b - a);
    const shape = groups.map(g => counts[g]).join('');

    let cat, tb;
    if (straightTop && flush) { cat = 8; tb = [straightTop]; }
    else if (shape === '41') { cat = 7; tb = groups; }
    else if (shape === '32') { cat = 6; tb = groups; }
    else if (flush) { cat = 5; tb = rs; }
    else if (straightTop) { cat = 4; tb = [straightTop]; }
    else if (shape === '311') { cat = 3; tb = groups; }
    else if (shape === '221') { cat = 2; tb = groups; }
    else if (shape === '2111') { cat = 1; tb = groups; }
    else { cat = 0; tb = rs; }

    let score = cat;
    for (let i = 0; i < 5; i++) score = score * 15 + (tb[i] || 0);
    let name = HAND_NAMES[cat];
    if (cat === 8 && straightTop === 14) name = 'Quinte flush royale';
    return { score, cat, name };
  }

  function bestHand(cards) {
    if (cards.length < 5) return null;
    let best = null;
    const n = cards.length;
    for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++)
      for (let c = b + 1; c < n; c++) for (let d = c + 1; d < n; d++)
        for (let e = d + 1; e < n; e++) {
          const five = [cards[a], cards[b], cards[c], cards[d], cards[e]];
          const v = eval5(five);
          if (!best || v.score > best.score) best = Object.assign(v, { cards: five });
        }
    return best;
  }

  // ---------- Partie ----------
  class Game {
    constructor(opts = {}) {
      this.settings = Object.assign({ stack: 1000, sb: 10, bb: 20 }, opts.settings || {});
      this.players = [];
      this.dealer = -1;
      this.stage = 'waiting'; // waiting | preflop | flop | turn | river | done
      this.board = [];
      this.deck = [];
      this.toAct = new Set();
      this.current = -1;
      this.currentBet = 0;
      this.minRaise = 0;
      this.log = [];
      this.result = null;
      this.handNo = 0;
      this.onChange = opts.onChange || (() => {});
      this.schedule = opts.schedule || ((fn, ms) => setTimeout(fn, ms));
      this.runoutDelay = opts.runoutDelay == null ? 1100 : opts.runoutDelay;
    }

    addLog(text, kind = 'info') {
      this.log.push({ text, kind, t: Date.now() });
      if (this.log.length > 80) this.log.shift();
    }

    player(id) { return this.players.find(p => p.id === id); }
    get inProgress() { return ['preflop', 'flop', 'turn', 'river'].includes(this.stage); }

    join(id, name) {
      let p = this.player(id);
      if (p) {
        p.connected = true;
        if (name) p.name = name.replace(/\|/g, '').slice(0, 16);
        this.addLog(`${p.name} est revenu`);
        return p;
      }
      if (this.players.length >= 9) throw new Error('La table est pleine (9 joueurs max)');
      p = {
        id, name: (name || 'Joueur').replace(/\|/g, '').slice(0, 16), chips: this.settings.stack,
        connected: true, hole: [], bet: 0, total: 0, folded: true, allIn: false,
        inHand: false, revealed: false, lastAction: '', rebuys: 0,
      };
      this.players.push(p);
      this.addLog(`${p.name} rejoint la table`);
      return p;
    }

    disconnect(id) {
      const p = this.player(id);
      if (!p) return;
      p.connected = false;
      this.addLog(`${p.name} s'est déconnecté`);
      if (!this.inProgress) {
        this.removeGone();
        this.onChange();
      } else if (!p.inHand) {
        this.onChange(); // retiré à la prochaine main
      } else if (this.players[this.current] === p) {
        this.act(p.id, 'fold');
      }
    }

    rebuy(id) {
      const p = this.player(id);
      if (!p) return;
      if (p.chips > 0) throw new Error('Tu as encore des jetons');
      if (this.inProgress && p.inHand) throw new Error('Attends la fin de la main');
      p.chips = this.settings.stack;
      p.rebuys++;
      this.addLog(`${p.name} se recave (${this.settings.stack})`);
    }

    // retire les joueurs déconnectés en gardant le bouton au bon endroit
    removeGone() {
      let d = this.dealer;
      this.players.forEach((p, i) => { if (!p.connected && i <= this.dealer) d--; });
      this.players = this.players.filter(p => p.connected);
      this.dealer = this.players.length ? Math.max(-1, Math.min(d, this.players.length - 1)) : -1;
    }

    nextIdx(from, pred) {
      const n = this.players.length;
      for (let k = 1; k <= n; k++) {
        const i = (from + k + n) % n;
        if (pred(this.players[i], i)) return i;
      }
      return -1;
    }

    canAct(p) { return p.inHand && !p.folded && !p.allIn; }
    live() { return this.players.filter(p => p.inHand && !p.folded); }

    put(p, amount) {
      const a = Math.min(amount, p.chips);
      p.chips -= a; p.bet += a; p.total += a;
      if (p.chips === 0) p.allIn = true;
      return a;
    }

    startHand() {
      if (this.inProgress) return;
      // retirer les joueurs partis
      this.removeGone();

      const seated = this.players.filter(p => p.chips > 0);
      if (seated.length < 2) {
        this.stage = 'waiting';
        this.result = null;
        this.board = [];
        for (const p of this.players) Object.assign(p, { hole: [], bet: 0, total: 0, inHand: false, folded: true, allIn: false, lastAction: '' });
        this.addLog('Il faut au moins 2 joueurs avec des jetons (recave possible)');
        this.onChange();
        return false;
      }
      this.handNo++;
      this.result = null;
      this.board = [];
      this.deck = shuffledDeck();
      for (const p of this.players) {
        Object.assign(p, { hole: [], bet: 0, total: 0, allIn: false, revealed: false, lastAction: '' });
        p.inHand = p.chips > 0;
        p.folded = !p.inHand;
      }
      const inHand = (p) => p.inHand;
      this.dealer = this.nextIdx(this.dealer, inHand);
      const headsUp = seated.length === 2;
      const sbIdx = headsUp ? this.dealer : this.nextIdx(this.dealer, inHand);
      const bbIdx = this.nextIdx(sbIdx, inHand);
      this.sbIdx = sbIdx; this.bbIdx = bbIdx;
      const sbP = this.players[sbIdx], bbP = this.players[bbIdx];
      this.put(sbP, this.settings.sb); sbP.lastAction = 'SB';
      this.put(bbP, this.settings.bb); bbP.lastAction = 'BB';
      this.currentBet = this.settings.bb;
      this.minRaise = this.settings.bb;

      for (let r = 0; r < 2; r++)
        for (const p of this.players) if (p.inHand) p.hole.push(this.deck.pop());

      this.stage = 'preflop';
      this.addLog(`— Main n°${this.handNo} — donneur : ${this.players[this.dealer].name}`, 'hand');
      this.toAct = new Set(this.players.filter(p => this.canAct(p)).map(p => p.id));
      this.current = bbIdx;
      this.proceed();
      return true;
    }

    legal(id) {
      const p = this.player(id);
      if (!p || !this.inProgress || this.players[this.current] !== p) return null;
      const toCall = Math.min(this.currentBet - p.bet, p.chips);
      const maxTo = p.bet + p.chips;
      const othersCanAct = this.players.some(o => o !== p && this.canAct(o));
      const canRaise = p.chips > toCall && othersCanAct;
      return {
        toCall, canCheck: toCall === 0, canRaise,
        minTo: Math.min(this.currentBet + this.minRaise, maxTo), maxTo,
        currentBet: this.currentBet, myBet: p.bet,
      };
    }

    act(id, action, amount) {
      const p = this.player(id);
      const L = this.legal(id);
      if (!L) throw new Error("Ce n'est pas ton tour");
      const others = () => this.players.filter(o => o !== p && this.canAct(o));

      if (action === 'allin') {
        if (L.canRaise) { action = 'raise'; amount = L.maxTo; } else action = 'call';
      }
      switch (action) {
        case 'fold':
          p.folded = true; p.lastAction = 'Couché';
          this.addLog(`${p.name} se couche`);
          break;
        case 'check':
          if (!L.canCheck) throw new Error('Tu ne peux pas checker');
          p.lastAction = 'Check';
          this.addLog(`${p.name} checke`);
          break;
        case 'call': {
          if (L.toCall === 0) { return this.act(id, 'check'); }
          const a = this.put(p, L.toCall);
          p.lastAction = p.allIn ? 'Tapis' : 'Suit';
          this.addLog(`${p.name} suit ${a}${p.allIn ? ' (tapis)' : ''}`);
          break;
        }
        case 'raise': {
          if (!L.canRaise) throw new Error('Relance impossible');
          let to = Math.floor(Number(amount));
          if (!Number.isFinite(to)) throw new Error('Montant invalide');
          to = Math.min(to, L.maxTo);
          if (to <= this.currentBet) throw new Error('La relance doit dépasser la mise actuelle');
          if (to < this.currentBet + this.minRaise && to < L.maxTo)
            throw new Error(`Relance minimum : ${this.currentBet + this.minRaise}`);
          const wasBet = this.currentBet === 0;
          const inc = to - this.currentBet;
          this.put(p, to - p.bet);
          if (inc >= this.minRaise) {
            this.minRaise = inc;
            this.toAct = new Set(others().map(o => o.id));
          } else {
            // relance incomplète (tapis) : les autres doivent au moins compléter
            others().forEach(o => { if (o.bet < to) this.toAct.add(o.id); });
          }
          this.currentBet = to;
          p.lastAction = p.allIn ? 'Tapis' : (wasBet ? 'Mise' : 'Relance');
          this.addLog(`${p.name} ${wasBet ? 'mise' : 'relance à'} ${to}${p.allIn ? ' (tapis)' : ''}`);
          break;
        }
        default: throw new Error('Action inconnue');
      }
      this.toAct.delete(p.id);
      this.proceed();
    }

    proceed() {
      const live = this.live();
      if (live.length === 1) return this.awardUncontested(live[0]);

      for (const pid of [...this.toAct]) {
        const p = this.player(pid);
        if (!p || !this.canAct(p)) this.toAct.delete(pid);
      }
      if (this.toAct.size > 0) {
        this.current = this.nextIdx(this.current, p => this.toAct.has(p.id));
        const cp = this.players[this.current];
        this.onChange();
        if (!cp.connected) this.schedule(() => {
          if (this.players[this.current] === cp && this.inProgress) this.act(cp.id, 'fold');
        }, 400);
        return;
      }
      // tour d'enchères terminé
      const canActCount = live.filter(p => !p.allIn).length;
      if (this.stage === 'river') return this.showdown();
      if (canActCount <= 1) return this.runout();
      this.nextStreet();
      this.toAct = new Set(this.players.filter(p => this.canAct(p)).map(p => p.id));
      this.current = this.dealer;
      this.proceed();
    }

    nextStreet() {
      for (const p of this.players) { p.bet = 0; if (!p.folded && !p.allIn) p.lastAction = ''; }
      this.currentBet = 0;
      this.minRaise = this.settings.bb;
      this.deck.pop(); // carte brûlée
      if (this.stage === 'preflop') { this.board.push(this.deck.pop(), this.deck.pop(), this.deck.pop()); this.stage = 'flop'; }
      else if (this.stage === 'flop') { this.board.push(this.deck.pop()); this.stage = 'turn'; }
      else if (this.stage === 'turn') { this.board.push(this.deck.pop()); this.stage = 'river'; }
    }

    runout() {
      this.current = -1;
      this.toAct.clear();
      // on retourne les cartes des joueurs à tapis
      for (const p of this.live()) p.revealed = true;
      const step = () => {
        if (this.stage === 'river') return this.showdown();
        this.nextStreet();
        this.onChange();
        this.schedule(step, this.runoutDelay);
      };
      this.onChange();
      this.schedule(step, this.runoutDelay);
    }

    potTotal() { return this.players.reduce((s, p) => s + p.total, 0); }

    awardUncontested(w) {
      const pot = this.potTotal();
      w.chips += pot;
      this.result = { winners: [{ id: w.id, name: w.name, amount: pot, hand: null }], uncontested: true };
      this.addLog(`${w.name} remporte ${pot}`, 'win');
      this.endHand();
    }

    buildPots() {
      const contrib = this.players.filter(p => p.total > 0);
      const levels = [...new Set(contrib.map(p => p.total))].sort((a, b) => a - b);
      const pots = [];
      let prev = 0;
      for (const lvl of levels) {
        let amount = 0;
        for (const p of contrib) amount += Math.max(0, Math.min(p.total, lvl) - prev);
        const eligible = contrib.filter(p => !p.folded && p.total >= lvl);
        if (eligible.length === 0 && pots.length) pots[pots.length - 1].amount += amount;
        else if (eligible.length === 0) pots.push({ amount, eligible: this.live() });
        else {
          const last = pots[pots.length - 1];
          if (last && last.eligible.length === eligible.length) last.amount += amount;
          else pots.push({ amount, eligible });
        }
        prev = lvl;
      }
      return pots;
    }

    showdown() {
      this.current = -1;
      const live = this.live();
      const hands = {};
      for (const p of live) { p.revealed = true; hands[p.id] = bestHand(p.hole.concat(this.board)); }
      const won = {};
      const pots = this.buildPots();
      pots.forEach((pot, i) => {
        const best = Math.max(...pot.eligible.map(p => hands[p.id].score));
        const winners = pot.eligible.filter(p => hands[p.id].score === best);
        const share = Math.floor(pot.amount / winners.length);
        let rest = pot.amount - share * winners.length;
        // jetons impairs : premier gagnant à gauche du donneur
        const ordered = [];
        for (let k = 1; k <= this.players.length; k++) {
          const q = this.players[(this.dealer + k) % this.players.length];
          if (winners.includes(q)) ordered.push(q);
        }
        for (const w of ordered) {
          const amt = share + (rest > 0 ? 1 : 0);
          if (rest > 0) rest--;
          w.chips += amt;
          won[w.id] = (won[w.id] || 0) + amt;
        }
        const label = pots.length > 1 ? (i === 0 ? 'le pot principal' : `le pot annexe ${i}`) : 'le pot';
        this.addLog(`${winners.map(w => w.name).join(' et ')} ${winners.length > 1 ? 'partagent' : 'remporte'} ${label} (${pot.amount}) — ${hands[winners[0].id].name}`, 'win');
      });
      this.result = {
        winners: Object.keys(won).map(id => {
          const p = this.player(id);
          return { id, name: p.name, amount: won[id], hand: hands[id].name, cards: hands[id].cards };
        }),
        hands: Object.fromEntries(live.map(p => [p.id, hands[p.id].name])),
      };
      this.endHand();
    }

    endHand() {
      this.stage = 'done';
      this.current = -1;
      this.toAct.clear();
      for (const p of this.players) p.bet = 0;
      this.removeGone();
      this.onChange();
    }

    // Vue personnalisée : on n'envoie jamais les cartes des autres (sauf abattage)
    viewFor(id, extra = {}) {
      const me = this.player(id);
      const L = this.legal(id);
      return Object.assign({
        me: id,
        stage: this.stage,
        handNo: this.handNo,
        board: this.board,
        pot: this.potTotal() - this.players.reduce((s, p) => s + p.bet, 0),
        potTotal: this.potTotal(),
        currentBet: this.currentBet,
        settings: this.settings,
        dealer: this.players[this.dealer] ? this.players[this.dealer].id : null,
        turn: this.players[this.current] ? this.players[this.current].id : null,
        players: this.players.map(p => ({
          id: p.id, name: p.name, chips: p.chips, bet: p.bet, folded: p.folded,
          allIn: p.allIn, inHand: p.inHand, connected: p.connected,
          lastAction: p.lastAction, rebuys: p.rebuys,
          cards: p.hole.length ? ((p.id === id || p.revealed) ? p.hole : [null, null]) : [],
        })),
        legal: L,
        myBest: me && me.hole.length && this.board.length >= 3 ? bestHand(me.hole.concat(this.board)).name : null,
        result: this.result,
        log: this.log.slice(-40),
      }, extra);
    }
  }

  const api = { Game, bestHand, eval5, RANKS, SUITS, rankOf, suitOf, shuffledDeck };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Poker = api;
})(typeof window !== 'undefined' ? window : globalThis);
